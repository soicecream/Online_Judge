## Vite

https://vitejs.cn/

- 使用npm创建vite项目：
  
  ```
  npm init vite@latest
  ```

- npm安装淘宝镜像：`npm config set registry https://registry.npm.taobao.org`

- ```js
  # npm 6.x
  npm init vite@latest my-vue-app --template vue
  
  # npm 7+, 需要额外的双横线：
  npm init vite@latest my-vue-app -- --template vue
  ```

- vite.config.js常用配置
  
  ```js
  import { defineConfig } from 'vite'
  import vue from '@vitejs/plugin-vue'
  const path = require('path')
  import { resolve } from 'path' // 主要用于alias文件路径别名
  // https://vitejs.dev/config/
  export default defineConfig({
    plugins: [vue()],
    // 是否自动在浏览器打开
    open: true,
    // 是否开启 https
    https: false,
    // 服务端渲染
    ssr: false,
    /**
     * 在生产中服务时的基本公共路径。
     * @default '/'
     */
    base: './',
    /**
     * 与“根”相关的目录，构建输出将放在其中。如果目录存在，它将在构建之前被删除。
     * @default 'dist'
     */
    outDir: 'dist',
    resolve: {
      alias: {
        '@': resolve(__dirname, '.', 'src'),
      },
    },
    // 反向代理
    server: {
      port: 8080,
      host: "0.0.0.0",
      // 是否自动在浏览器打开
      open: true,
      // 是否开启 https
      https: false,
      proxy: {
        '/api': {
          target: 'https://blog.csdn.net/weixin_45292658',
          changeOrigin: true,
          rewrite: (path) => path.replace(/^\/api/, ''),
        },
      },
    },
  })
  ```

## 安装vue-router4.x



-  `npm install vue-router -S` 

[Vue Router](https://router.vuejs.org/zh/)


- 创建 router 文件夹，放一个index.js，内容：
  
  ```js
  import { createRouter, createWebHistory } from 'vue-router' 
  const routes = [
   {
   path: '/',
   name: 'Home',
   component: () => import('../views/Home.vue')
   }
  ] 
  const router = createRouter({
   history: createWebHistory("/"),
   routes: routes,
  }) 
  /**
  
  - 输出对象
     */
    export default router;
  ```
  
  

- 
  

- 配置 main.js

```js
import router from './router'
createApp(App).use(router).mount('#app')
```

- App.vue改造一下：
  
  ```html
   <!--  只显示路由界面 -->
  <template>
    <router-view />
  </template>
  ```

## Element-Plus

- 安装Element-Plus
  
  npm i element-plus -S

- 快速开始，引入Element-Plus（EP）
  
  在main.js里面配置：
  
  ```js
  import ElementPlus from 'element-plus'
  import 'element-plus/dist/index.css
  
  createApp(App).use(router).use(ElementPlus).mount('#app')'
  ```

- 使用：
  
  ```js
   <el-button type="primary">
        Hello 青哥哥
   </el-button>
  ```
  
  <img src="file:///C:/Users/Administrator/AppData/Roaming/marktext/images/2022-07-02-22-19-16-image.png" title="" alt="" width="334">

- icon的使用：
  
  ```js
  npm install @element-plus/icons-vue -S
  
  引入：
  
  <script setup>
  import {Edit, Position} from '@element-plus/icons-vue'
  </script>
  
  2种使用方式：
  
  <el-icon><Edit /></el-icon>
  
  <Edit style="width: 1em; height: 1em; margin-right: 8px" />
       
  ```
  
  
