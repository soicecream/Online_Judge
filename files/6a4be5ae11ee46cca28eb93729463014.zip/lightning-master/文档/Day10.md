## 分页查询
- 学习前端分页器 ``el-pagination``
- 学习 pagination 的2个函数`handleSizeChange`，`handleCurrentChange` 和2个属性 `currentPage`, `pageSize`
- UserController 新增后台接口 /user/page,可以实现分页条件模糊查询
- Mybatis查询错误：org.apache.ibatis.binding.BindingException: Parameter 'currentPage' not found. Available parameters are [arg1, arg0, param1, param2]
- 前端传的参数currentPage是表示从第几页进行查询，而数据库里的limit函数第一个参数表示从第几个数据开始查，我们需要进行一定的转换
- 前端页面集成后端接口，实现分页参数查询 `currentPage`  `pageSize`
- 完成前端集成后台多条件查询  `username` `phone` `email` 等联合条件参数的模糊分页查询
- 使用pageHelper 1.3.0
```
<dependency>
    <groupId>com.github.pagehelper</groupId>
    <artifactId>pagehelper-spring-boot-starter</artifactId>
    <version>1.3.0</version>
</dependency>
```
- 页面设置中文