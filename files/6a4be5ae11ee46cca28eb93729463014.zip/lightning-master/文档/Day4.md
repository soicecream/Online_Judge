## 引用表单验证，实现表单校验

## 封装request.js

## 使用 request对象请求后台

## 开始搭建Springboot服务