## 前端的组件
`<el-icon>`
`<el-dialog>`

## dialog表单

- 完成前端 dialog表单数据的校验
- 完成前端新增数据接口的调用
- 完成数据的刷新
-  state.form = JSON.parse(JSON.stringify(row)) 实现了数据的转让
- 新增的时候注意初始化数据
- 保存的时候如何区分编辑还是新增？
- request.delete()  这个你改了吗？ 接口的请求方式要注意
- 使用`el-popconfirm` 来保护删除按钮

