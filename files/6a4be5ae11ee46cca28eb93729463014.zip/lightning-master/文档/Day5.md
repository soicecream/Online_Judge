## 新建 Springboot
https://start.aliyun.com

## 组件（Dependency）
- Spring Web (SpringMVC)
- Mysql
- Mybatis
- Lombok

## Maven导包（很重要）
当看到 `updating index...` 说明他已经下载好了依赖，正在更新本地文件索引
当你看到 `@SpringBootApplication` 这个注解变成了黄色，表示你的项目OK了，maven下载更新完成

## 学习内容
- SpringMVC
- Mybatis
- Lombok
- Restful接口