## 前端请求
404：请求的接口不存在
405 错误：表示资源请求的方式不对，比如后台接口是POST，而前端使用了 GET请求，这时候就出现了405 的Http错误
400 错误：表示你的请求参数不符合后台接口的要求

@RequestBody接受一个json参数

跨域请求错误：Access to XMLHttpRequest at 'http://localhost:9090/user/login' from origin 'http://localhost:8080' has been blocked by CORS policy: Response to preflight request doesn't pass access control check: No 'Access-Control-Allow-Origin' header is present on the requested resource.
跨域：IP或者端口不同会出现跨域错误


前端登录请求：搞清楚整个登录请求的数据流向
前端页面数据渲染的流程