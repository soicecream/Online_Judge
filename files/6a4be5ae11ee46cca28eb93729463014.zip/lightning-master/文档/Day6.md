# 数据库单表的CRUD

## 1. 什么是JSON对象？什么是JSON数组
{
    "username": "青哥哥",
    "password": null
}

[
    {
    "username": "青哥哥",
    "password": null
    },
    {
    "username": "青哥哥",
    "password": null
    }
]

## 怎么创建数据库表（Mysql）
字符集：utf8mb4，utf8mb4_unicode_ci
什么是数据库的三范式
了解数据库的CRUD语句

```
SELECT * FROM user;

SELECT * FROM user WHERE id = 1;

SELECT * FROM user WHERE username = '111' and PASSWORD = '12222';

INSERT INTO `user`(username, password) values('admin', 'admin');


update `user` set password = '123' where username = 'admin';

DELETE from `user` where id = 1;

```

## 开始写UserMapper.xml和UserDao接口
```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE mapper
        PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
        "http://mybatis.org/dtd/mybatis-3-mapper.dtd">

<mapper namespace="com.example.springboot.dao.UserDao">

</mapper>
```

MybatisX插件


## 接口开发
了解   @Autowired 主键

常见错误：Field userDao in com.example.springboot.SpringbootApplication required a bean of type 'com.example.springboot.dao.UserDao' that could not be found.

前端报错：{
"timestamp": "2022-07-29T13:37:57.031+00:00",
"status": 500,
"error": "Internal Server Error",
"message": "",
"path": "/"
}
为什么？  后台错了！去查后台的问题
异常信息：
org.apache.ibatis.exceptions.TooManyResultsException: Expected one result (or null) to be returned by selectOne(), but found: 2

通过  #{id} 去接受参数，预编译，防止sql注入

{GET /user}: There is already 'userController' bean method
同一个 controller里面定义了2个或多个相同路径的接口

异常：
org.apache.ibatis.binding.BindingException: Parameter 'username' not found. Available parameters are [arg1, arg0, param1, param2]
在方法参数里面加上 @Param() 注解， @Param("username") String username

非常重要的技巧：debug断点

了解新增接口：  @PostMapping，@RequestBody  @Validated 

异常：唯一键冲突
Duplicate entry 'qing' for key 'uni_username'; 

@PutMapping 更新资源

Restful风格

资源区分：
1. url路径
2. url相同时根据请求方式

数据库插入中文乱码

@DeleteMapping 的使用