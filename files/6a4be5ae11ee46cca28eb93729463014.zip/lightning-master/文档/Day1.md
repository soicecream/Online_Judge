## 软件环境

- node （https://npmmirror.com/mirrors/node/v16.15.1/node-v16.15.1-x64.msi）
  
  **CMD验证：**![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-02-30-image.png)

- jdk1.8 （https://download.oracle.com/otn/java/jdk/8u333-b02/2dee051a5d0647d5be72a7c0abff270e/jdk-8u333-windows-x64.exe）
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-00-48-image.png)
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-01-49-image.png)

- mysql5.7（https://downloads.mysql.com/archives/get/p/23/file/mysql-5.7.37-winx64.zip）
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-00-07-image.png)

- navicat （可选，付费的，需要破解，可以去公众号 Java学习指南，回复软件获取破解的安装方式）

- Idea2020（写Java必备的一个软件）
  
  设置：
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-10-30-image.png)
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-11-35-image.png)
  encoding和maven配置
  
  ![](C:\Users\Administrator\AppData\Roaming\marktext\images\2022-06-28-20-59-14-image.png)
  
  `常用插件` : Vue.js、MybatisX、Codota

         让你所有项目都生效配置：

       <img title="" src="file:///C:/Users/Administrator/AppData/Roaming/marktext/images/2022-06-28-20-16-30-image.png" alt="" width="613">

## 常用的资源网站

- CSDN

- 简书

- 掘金

- 博客园

这些网站大多数都是程序员自己写的博客，所以比较靠谱，大家会经常用到
