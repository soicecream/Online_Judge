package com.example.springboot.entity;

import lombok.Data;

@Data
public class User {
    private Integer id;
    // 用户名
    private String username;
    // 密码
    private String password;
    private String sex;
    private Integer age;
    private String phone;
    private String email;
    private String address;
    private String avatar;
}
